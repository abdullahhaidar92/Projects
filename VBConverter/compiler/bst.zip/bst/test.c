20 10 () () 40 30 () () 50 () ()  // Binary Search Tree
20 10 () () 40 15 () () 50 () ()  // Not Binary Search Tree