void main(){
int i,x,y,z,j;
for(i=0;i<=6;i+=1)
{ if(y>4 && x<0)
   {for(j=0;j<=30;j+=3)
    printf("88");
    }
    
 else
  { printf("99");
    x=y+z;
    while(z>0) for(i=0;i<8;i++)while(x>0)if(x>9)printf("00");
   }
   printf(" X is %d and Y is %d ",x,y);
 }
}




































