void main(){
int x,y,z=8,i;
if(y>4 && x<0)for(i=0;i<=30;i+=3)printf("88");else printf("88");
printf("Hello %d How Are %c",x,z);
}




































