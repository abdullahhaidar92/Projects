void main(){
int x,y,z=x+y;
int a,b,t=9,e,w=4;
char s='u';
x=9;
y=5;
scanf(" %d %c ",&x,&y);
printf("Hello ");
if(x>=9||y==9)if(x>=a*3||y==8+b)printf("88");else printf("99");
printf("How  %d  Are %d you ",x+7,y);
}





































