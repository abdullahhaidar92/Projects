void main(){
int a,x;

if(a>0)
	while(x>0)
	   	if(x>0)
	   	printf("88");
else
 	printf("vv");	  
 	 

}



































