module VBConverter {
    requires javafx.fxml;
    requires javafx.controls;
    requires richtextfx.fat;

    opens editor;

}